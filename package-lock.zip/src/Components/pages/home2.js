// import React, { useState, useEffect } from 'react';
// import bg2 from "../../Assets/images/circle.jpg"

// import Footer from '../common/footer'




// function Home2() {
//   return (

// <div>



// <div className='sec2 uk-background-cover' style={{marginTop:"2vh"}}  data-src = "https://images.unsplash.com/photo-1490822180406-880c226c150b?fit=crop&w=650&h=433&q=80" uk-img = "loading : eager" >
//     <div className='uk-flex uk-flex-center uk-flex-middle uk-text-center sec2heading ' >
// </div>
// <div class="uk-width-1-2@m uk-text-center uk-margin-auto uk-margin-auto-vertical">
//         <h1 uk-parallax="opacity: 0,1; y: -100,0; scale: 2,1; end: 50vh + 50%;">Headline</h1>
//         <p uk-parallax="opacity: 0,1; y: 100,0; scale: 0.5,1; end: 50vh + 50%;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>            

// </div>
// <ul class="uk-subnav uk-subnav-pill uk-flex-center tabbuttons " uk-switcher="animation: uk-animation-slide-left-medium, uk-animation-slide-right-medium">
//     <li className='tbbtn'><a>Threat Assesment </a> </li>
//     <li className='tbbtn'><a>Pen Testing</a></li>
//     <li className='tbbtn'  ><a > Risk Mitigation </a></li>
//     </ul>    
// <ul class="uk-switcher uk-margin">
// <li><div className='uk-container uk-flex uk-padding ' >
//         <div>
//           <p className='heading'>Market Your<br></br>  Brand</p>

//           <div className='text1 ' >
//           <p>With Social Pigeons, a network of digital wings, you can persuade, engage, and encourage customers to market the brand amazingly. Here, you can digitally get connected with the creators that help your business grow in a whole new direction.</p>
//           </div>
//         </div>
//         <div className='' >
//           <img className='tabimg' src={bg2}  />
//         </div>
//       </div></li>


//     <li><div className='uk-container uk-flex uk-padding ' >
//         <div>
//           <p className='heading'>Market Your<br></br>  Brand</p>

//           <div className='text1 ' >
//           <p>With Social Pigeons, a network of digital wings, you can persuade, engage, and encourage customers to market the brand amazingly. Here, you can digitally get connected with the creators that help your business grow in a whole new direction.</p>
//           </div>
//         </div>
//         <div className='' >
//           <img className='tabimg' src={bg2}  />
//         </div>
//       </div></li>


//    <li><div className='uk-container uk-flex uk-padding ' >
//         <div>
//           <p className='heading'>Market Your<br></br>  Brand</p>

//           <div className='text1 ' >
//           <p>With Social Pigeons, a network of digital wings, you can persuade, engage, and encourage customers to market the brand amazingly. Here, you can digitally get connected with the creators that help your business grow in a whole new direction.</p>
//           </div>
//         </div>
//         <div className='' >
//           <img className='tabimg' src={bg2}  />
//         </div>
//       </div></li>
// </ul>
// </div>


// <div className=' uk-background-cover' data-src = {bg2} uk-img= "loading:eager" >
// <div className=' uk-container uk-padding    ' > 
//     <div className=' uk-grid' uk-grid="">
//   <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Threat Assessment</h3>
//                 <p >Our experienced team of security analysts will identify potential security threats to your company and provide you with a comprehensive report outlining areas of concern.</p>
//             </div>
//         </div>
//     </div>

//     <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Penetration Testing</h3>
//                 <p >Identify vulnerabilities in your organization’s cybersecurity defenses from a hacker’s perspective. Our team of experts will simulate a cyber attack to identify potential risks and provide you with recommendations to address them.</p>
//             </div>
//         </div>
//     </div>
//     <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Risk Mitigation</h3>
//                 <p >Our team of experts will work with your organization to address any vulnerabilities identified through our threat assessment and penetration testing services. We will provide you with a comprehensive plan to mitigate risks and protect your sensitive information.</p>
//             </div>
//         </div>
//     </div>

//     <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Cybersecurity Training</h3>
//                 <p >We offer comprehensive cybersecurity training for your employees to reduce the risk of human error and ensure that your organization is equipped to handle potential cyber threats.</p>
//             </div>
//         </div>
//     </div>
//     <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Incident Response</h3>
//                 <p >In the event of a cyber attack, our team of experts is available 24/7 to respond to the incident and minimize the impact on your organization. We will work with your team to address the issue and prevent it from happening again in the future.</p>
//             </div>
//         </div>
//     </div>

//     <div className='card uk-light  ' >
//         <div class="neonbg crdimg uk-card uk-card-default">
//             <div class="cardtext uk-card-body">
//                 <h3 class=" wfont">Compliance Consulting</h3>
//                 <p >We offer compliance consulting services to ensure that your organization is meeting the necessary regulatory requirements and industry standards for cybersecurity. Our team of experts will work with you to identify any gaps in your current compliance program and provide recommendations to address them.</p>
//             </div>
//         </div>
//     </div>
//     </div>
//   </div>
// </div>



// <div className='anid'>
// <p className='anip' >
//   Spice up your type with CSS
//   <span className='anis'>
//     Animated text fill
//   </span>
//   &mdash; no JavaScript required &mdash;
// </p>
// </div>



//     <Footer/>

// </div>

//   );
// }

// export default Home2











